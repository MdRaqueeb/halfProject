package com.kks.Project.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.kks.Project.entity.Publisher;

public interface PublisherRepo extends JpaRepository<Publisher, Integer>{

}
